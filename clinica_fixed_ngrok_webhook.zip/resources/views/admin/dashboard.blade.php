@extends('layouts.app')
@section('content')
<h1 class="text-2xl font-bold">Dashboard Admin</h1>
@endsection
