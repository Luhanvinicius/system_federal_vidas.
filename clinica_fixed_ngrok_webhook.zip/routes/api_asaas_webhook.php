<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AsaasWebhookController;

Route::get('/asaas/webhook', [AsaasWebhookController::class, 'ping']);
Route::post('/asaas/webhook', [AsaasWebhookController::class, 'handle']);
