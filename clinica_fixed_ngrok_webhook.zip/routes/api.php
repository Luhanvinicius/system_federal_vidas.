<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\NearbyClinicsController;

Route::get('/clinics/nearby', NearbyClinicsController::class);

Route::post('/asaas/webhook', [AsaasWebhookController::class, 'handle']);

require __DIR__.'/api_asaas_webhook.php';

require __DIR__.'/api_poll_status.php';
