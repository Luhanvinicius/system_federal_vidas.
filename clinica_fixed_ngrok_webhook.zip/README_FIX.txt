PASSOS:
1) Extraia este zip na raiz do projeto Laravel, sobrescrevendo arquivos.
2) Rode:
   composer dump-autoload -o
   php artisan optimize:clear
3) Acesse:
   - /login (admin@clinica.com / password)
   - /admin/dashboard (admin) ou /client/dashboard (cliente)
