
<script>
(function(){
  const statusUrl = "<?php echo e(route('appointments.status', $appointment)); ?>";
  const successUrl = "<?php echo e(route('appointments.success', $appointment)); ?>";
  async function tick(){
    try {
      const res = await fetch(statusUrl, {headers: {'X-Requested-With':'XMLHttpRequest'}});
      if(res.ok){
        const data = await res.json();
        if ((data.status || '').toLowerCase() === 'paid') {
          window.location.href = successUrl;
          return;
        }
      }
    } catch(e) { /* silencia */ }
    setTimeout(tick, 3000);
  }
  setTimeout(tick, 3000);
})();
</script>
<?php /**PATH F:\clinica\clinica\resources\views/client/appointments/_polling_success_snippet.blade.php ENDPATH**/ ?>