<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('appointments', function (Blueprint $table) {
            if (!Schema::hasColumn('appointments','status')) {
                $table->string('status')->default('awaiting_payment')->index();
            }
            if (!Schema::hasColumn('appointments','co_pay_price_cents')) {
                $table->integer('co_pay_price_cents')->nullable();
            }
            if (!Schema::hasColumn('appointments','asaas_payment_id')) {
                $table->string('asaas_payment_id')->nullable()->index();
            }
            if (!Schema::hasColumn('appointments','asaas_invoice_url')) {
                $table->string('asaas_invoice_url')->nullable();
            }
            if (!Schema::hasColumn('appointments','pix_qr_code_base64')) {
                $table->longText('pix_qr_code_base64')->nullable();
            }
            if (!Schema::hasColumn('appointments','pix_payload')) {
                $table->text('pix_payload')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('appointments', function (Blueprint $table) {
            // não remove por segurança em downgrade
        });
    }
};
