@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-3">Pagamento da Coparticipação</h2>

    <div class="card mb-3">
        <div class="card-body">
            <p class="mb-1"><strong>Especialidade:</strong> {{ optional($appointment->specialty)->name }}</p>
            <p class="mb-1"><strong>Valor:</strong> R$ {{ number_format($appointment->copay_value ?? 0, 2, ',', '.') }}</p>
            <p class="mb-3"><strong>Status:</strong> {{ $appointment->status }}</p>

            @if($appointment->asaas_qr_code_url)
                <h5>Escaneie o QR Code PIX</h5>
                <img src="data:image/png;base64,{{ $appointment->asaas_qr_code_url }}" alt="QR Code PIX" style="max-width:240px;">
                @if($appointment->asaas_qr_code_payload)
                    <div class="mt-3">
                        <label class="form-label">Copia e Cola (PIX)</label>
                        <textarea class="form-control" rows="3" readonly>{{ $appointment->asaas_qr_code_payload }}</textarea>
                    </div>
                @endif
                @if($appointment->asaas_invoice_url)
                    <div class="mt-3">
                        <a class="btn btn-outline-primary" href="{{ $appointment->asaas_invoice_url }}" target="_blank">Abrir cobrança</a>
                    </div>
                @endif
            @else
                <div class="alert alert-warning">
                    Não foi possível gerar o QR Code no momento. Tente novamente mais tarde.
                </div>
            @endif
        </div>
    </div>
</div>
@endsection
