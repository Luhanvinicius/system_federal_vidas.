{{-- Redireciona automaticamente quando o pagamento virar "paid" --}}
<script>
(function(){
  const statusUrl = "{{ route('appointments.status', $appointment) }}";
  const successUrl = "{{ route('appointments.success', $appointment) }}";
  async function tick(){
    try {
      const res = await fetch(statusUrl, {headers: {'X-Requested-With':'XMLHttpRequest'}});
      if(res.ok){
        const data = await res.json();
        if ((data.status || '').toLowerCase() === 'paid') {
          window.location.href = successUrl;
          return;
        }
      }
    } catch(e) { /* silencia */ }
    setTimeout(tick, 3000);
  }
  setTimeout(tick, 3000);
})();
</script>
