Como aplicar:
1) Copie estes arquivos para dentro do seu projeto, mantendo os caminhos.
2) Rodar:
   php artisan view:clear
   php artisan optimize:clear
   php artisan migrate   (se ainda não existir a coluna clinic_id)
3) Abra /appointments/create, digite o CEP e selecione uma clínica (obrigatório).
