<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class AsaasService
{
    protected string $baseUrl;
    protected string $token;

    public function __construct()
    {
        $this->baseUrl = rtrim(config('services.asaas.base_url', 'https://sandbox.asaas.com/api/v3'), '/');
        $this->token = config('services.asaas.api_key');
    }

    public function createPixCharge(string $name, string $email, float $value, string $description): array
    {
        $payload = [
            'customer' => [
                'name' => $name,
                'email' => $email,
            ],
            'billingType' => 'PIX',
            'value' => $value,
            'description' => $description,
        ];

        // A API do Asaas espera o customerId; mas se enviar objeto customer, alguns ambientes aceitam.
        // Para sandbox, faremos uma criação rápida de customer quando necessário.
        // 1) criar/obter customer
        $customerId = $this->ensureCustomer($name, $email);

        $payment = [
            'customer' => $customerId,
            'billingType' => 'PIX',
            'value' => $value,
            'description' => $description,
        ];

        $res = Http::withToken($this->token)->post("{$this->baseUrl}/payments", $payment);
        if (!$res->successful()) {
            throw new \RuntimeException('Erro Asaas: '.$res->status().' '.$res->body());
        }
        $data = $res->json();

        // QRCode details endpoint
        $paymentId = $data['id'] ?? null;
        $qr = null;
        if ($paymentId) {
            $qrRes = Http::withToken($this->token)->get("{$this->baseUrl}/payments/{$paymentId}/pixQrCode");
            if ($qrRes->successful()) {
                $qr = $qrRes->json();
            }
        }

        return [
            'payment' => $data,
            'qr' => $qr,
        ];
    }

    protected function ensureCustomer(string $name, string $email): string
    {
        $find = Http::withToken($this->token)->get("{$this->baseUrl}/customers", ['email' => $email]);
        if ($find->successful() && ($find->json()['totalCount'] ?? 0) > 0) {
            return $find->json()['data'][0]['id'];
        }
        $create = Http::withToken($this->token)->post("{$this->baseUrl}/customers", [
            'name' => $name,
            'email' => $email,
        ]);
        if (!$create->successful()) {
            throw new \RuntimeException('Erro ao criar cliente Asaas: '.$create->status().' '.$create->body());
        }
        return $create->json()['id'];
    }
}
