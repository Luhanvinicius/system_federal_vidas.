<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use Illuminate\Support\Facades\Auth;

class PaymentStatusController extends Controller
{
    public function status(Appointment $appointment)
    {
        $user = Auth::user();
        if (!$user) abort(401);
        if ($appointment->user_id !== $user->id && (($user->role ?? null) !== 'admin')) {
            abort(403);
        }
        return response()->json([
            'id' => $appointment->id,
            'status' => $appointment->status,
            'paid_at' => $appointment->paid_at ?? null,
        ]);
    }

    public function success(Appointment $appointment)
    {
        $user = Auth::user();
        if (!$user) return redirect()->route('login');
        if ($appointment->user_id !== $user->id && (($user->role ?? null) !== 'admin')) {
            abort(403);
        }
        if ($appointment->status !== 'paid') {
            return redirect()->route('appointments.payment', $appointment);
        }
        return view('client.appointments.success', compact('appointment'));
    }
}
