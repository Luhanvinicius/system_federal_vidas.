<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\Appointment;

class AsaasWebhookController extends Controller
{
    public function ping(Request $request)
    {
        return response()->json(['ok' => true, 'requires' => 'POST', 'token' => $request->query('token')]);
    }

    public function handle(Request $request)
    {
        // Validação simples por token na query string
        $expected = env('ASAAS_WEBHOOK_TOKEN');
        if ($expected && $request->query('token') !== $expected) {
            return response()->json(['error' => 'unauthorized'], 401);
        }

        $payload = $request->all();
        Log::info('ASAAS webhook received', ['payload' => $payload]);

        // Normalização de campos (v3 usa formatos diferentes)
        $paymentId  = $this->get($payload, ['payment.id','data.payment.id','data.id','id']);
        $status     = strtoupper((string) $this->get($payload, ['payment.status','data.payment.status','data.status','status']));
        $invoiceUrl = $this->get($payload, ['payment.invoiceUrl','data.payment.invoiceUrl','invoiceUrl']);

        if (!$paymentId && !$invoiceUrl) {
            Log::warning('ASAAS webhook: no identifiers present');
            return response()->json(['ok' => true, 'ignored' => true]);
        }

        // Busca appointment por payment_id OU invoice_url
        $appointment = Appointment::query()
            ->when($paymentId, fn($q)=>$q->orWhere('asaas_payment_id', $paymentId))
            ->when($invoiceUrl, fn($q)=>$q->orWhere('asaas_invoice_url', $invoiceUrl))
            ->first();

        if (!$appointment) {
            Log::warning('ASAAS webhook: appointment not found', ['paymentId' => $paymentId, 'invoiceUrl' => $invoiceUrl]);
            return response()->json(['ok' => true, 'not_found' => true]);
        }

        $paidStatuses = ['RECEIVED','RECEIVED_IN_CASH','CONFIRMED','PAYMENT_CONFIRMED'];
        if (in_array($status, $paidStatuses, true)) {
            $dirty = [];

            if ($paymentId && $appointment->asaas_payment_id !== $paymentId) {
                $appointment->asaas_payment_id = $paymentId;
                $dirty['asaas_payment_id'] = $paymentId;
            }
            if ($invoiceUrl && !$appointment->asaas_invoice_url) {
                $appointment->asaas_invoice_url = $invoiceUrl;
                $dirty['asaas_invoice_url'] = $invoiceUrl;
            }
            if ($appointment->status !== 'paid') {
                $appointment->status = 'paid';
                $dirty['status'] = 'paid';
            }
            if (\Schema::hasColumn('appointments', 'paid_at') && !$appointment->paid_at) {
                $appointment->paid_at = now();
                $dirty['paid_at'] = $appointment->paid_at;
            }

            $appointment->save();
            Log::info('ASAAS webhook: appointment marked as PAID', ['appointment_id' => $appointment->id, 'dirty' => $dirty]);
        } else {
            Log::info('ASAAS webhook: status not paid', ['status' => $status]);
        }

        return response()->json(['ok' => true]);
    }

    private function get(array $arr, array $paths, $default = null)
    {
        foreach ($paths as $p) {
            $v = data_get($arr, $p);
            if ($v !== null && $v !== '') return $v;
        }
        return $default;
    }
}
